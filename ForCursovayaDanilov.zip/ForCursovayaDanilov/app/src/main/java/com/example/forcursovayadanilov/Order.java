package com.example.forcursovayadanilov;

public class Order {
    private String nameAndLastName;
    private String phone;
    private String dessert;
    private String coffee;
    private String address;
}
