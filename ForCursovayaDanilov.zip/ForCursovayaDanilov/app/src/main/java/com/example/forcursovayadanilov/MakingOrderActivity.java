package com.example.forcursovayadanilov;

import android.content.Intent;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MakingOrderActivity extends AppCompatActivity {
    TextView textView;
    TextInputEditText nameAndLastName,phoneNumber, desserts, coffee;
    Button btn_order,btn_back;
    ImageView bgfororderingVIew;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_making_order);

        ImageView image = findViewById(R.id.bgfororderingVIew);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            image.setRenderEffect(RenderEffect.createBlurEffect(20, 20, Shader.TileMode.MIRROR));
        }

        FirebaseApp.initializeApp(this);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("order");

        nameAndLastName = findViewById(R.id.nameAndLastName);
        phoneNumber = findViewById(R.id.phoneNumber);
        desserts = findViewById(R.id.desserts);
        coffee = findViewById(R.id.coffee);
        btn_order = findViewById(R.id.btn_order);
        btn_back = findViewById(R.id.btn_back);


        btn_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name_and_lastname = nameAndLastName.getText().toString();
                String phoneNmb = phoneNumber.getText().toString();
                String dessert = desserts.getText().toString();
                String cffe = coffee.getText().toString();

                nameAndLastName.setError(null);
                phoneNumber.setError(null);
                desserts.setError(null);
                coffee.setError(null);

                if (!isValidPhoneNumber(phoneNmb)) {
                    phoneNumber.setError("Invalid phone number: +7XXXXXXXXXX");
                    return;
                }

                if (TextUtils.isEmpty(phoneNmb) || TextUtils.isEmpty(name_and_lastname)) {
                    phoneNumber.setError("Enter email and password");
                    return;
                }

            }

            private boolean isValidPhoneNumber(String phoneNumber) {
                String regex = "^\\+7[0-9]{10}$";
                return phoneNumber.matches(regex);
            }
        });
                btn_back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Button openButton = findViewById(R.id.buyTheCoffe);
                        openButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent i = new Intent(MakingOrderActivity.this, MainActivity.class);
                                startActivity(i);
                            }
                        });
                    }
                });
            }
        }
